echo "############## Starting Firmware Dump ##############"

mkdir -p /mnt/backup

cat /proc/mtd > /mnt/backup/mtd.txt

dd if=/dev/mtdblock0 of=/mnt/backup/mtdblock0.bin
dd if=/dev/mtdblock1 of=/mnt/backup/mtdblock1.bin
dd if=/dev/mtdblock2 of=/mnt/backup/mtdblock2.bin
dd if=/dev/mtdblock3 of=/mnt/backup/mtdblock3.bin
dd if=/dev/mtdblock4 of=/mnt/backup/mtdblock4.bin
dd if=/dev/mtdblock5 of=/mnt/backup/mtdblock5.bin

if [ -e /mnt/Factory ]; then
    mv /mnt/Factory /mnt/Factory.done
fi

reboot
